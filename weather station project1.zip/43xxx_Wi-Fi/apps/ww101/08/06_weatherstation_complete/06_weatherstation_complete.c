/*
 * Broadcom Proprietary and Confidential. Copyright 2016 Broadcom
 * All Rights Reserved.
 *
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
 * the contents of this file may not be disclosed to third parties, copied
 * or duplicated in any form, in whole or in part, without the prior
 * written permission of Broadcom Corporation.
 */

/** @file
 *
 * A rudimentary AWS IOT publisher application which demonstrates how to connect to
 * AWS IOT cloud (MQTT Broker) and publish MQTT messages for a given topic.
 *
 * This application publishes "LIGHT ON" or "LIGHT OFF" message for each button press
 * to topic "WICED_BULB" with QOS1. Button used is WICED_BUTTON1 on the WICED board.
 * If we press the button first time it publishes "LIGHT OFF" and if we press next the same button
 * it will publish "LIGHT ON".
 *
 * To run the app, work through the following steps.
 *  1. Modify Wi-Fi configuration settings CLIENT_AP_SSID and CLIENT_AP_PASSPHRASE in wifi_config_dct.h to match your router settings.
 *  2. Update the AWS MQTT broker address (MQTT_BROKER_ADDRESS) if needed.
 *  3. Make sure AWS Root Certifcate 'resources/apps/aws_iot/rootca.cer' is up to date while building the app.
 *  4. Copy client certificate and private key for the given AWS IOT user in resources/apps/aws_iot folder.
 *     Ensure that valid client certificates and private keys are provided for the AWS IOT user in resources/apps/aws_iot folder.
 *  5. Build and run this application.
 *  6. Run another application which subscribes to the same topic.
 *  7. Press button WICED_BUTTON1 to publish the messages "LIGHT ON" or LIGHT OFF" alternatively and check if
 *     it reaches subscriber app running on the other WICED board (which can be anywhere but connected to internet)
 *
 */

#include "wiced.h"
#include "mqtt_api.h"
#include "resources.h"
#include "JSON.h"


#include "u8g_arm.h"

#define RETRIES (1)
#define DISABLE_DMA (WICED_TRUE)
#define NUM_MESSAGES (1)
#define TEMPERATURE_REG 0x07
#define BUTTON_REG	0x06
#define FIRSTPAGE	0x1
#define SECONDPAGE	0x2
#define TIMER_TIME	(200)
#define MQTT_SUBSCRIBE_RETRY_COUNT          (3)

volatile uint32_t page = 0x00;

/* Strings to hold the results  of sensor reads*/
char temp_str[25];
char humidity_str[25];
char light_str[25];
char pot_str[25];
char ip_str[25];
char name_str[25];
//char* devicename = "ww101_02";
char* devicename = "";
char* alert = "true";

uint32_t i=0;

wiced_mqtt_object_t   mqtt_object_publish;
//wiced_mqtt_object_t   mqtt_object_subscribe;
wiced_result_t        ret = WICED_SUCCESS;
uint32_t              size_out = 0;
int                   connection_retries = 0;
int                   retries = 0;
int                   retries1 = 0;
int                   retries2 = 0;
int                   retries3 = 0;
char*                 msg[100]; //for sending mqtt data
char*                 msgS[100];//for recieving mqtt data
wiced_ip_address_t grsm;

/* Rx buffer is used to get temperature, humidity, light, and POT data - 4 bytes each */
struct {
	float temp;
	float humidity;
	float light;
	float pot;
} rx_buffer;

/* Rx buffer is used to get temperature, humidity, light, and POT data - 4 bytes each */
struct {
	uint8_t ButtonStatus;
} rx_buffer1;

u8g_t display;

/* Initialize PSoC analog co-processor I2C interface and set the offset */
const wiced_i2c_device_t psoc_i2c = {
		.port 			= WICED_I2C_1,
		.address 		= 0x42,
		.address_width 	= I2C_ADDRESS_WIDTH_7BIT,
		.speed_mode 	= I2C_STANDARD_SPEED_MODE
};


/* Initialize the OLED display */
wiced_i2c_device_t display_i2c =
{
		.port          = WICED_I2C_1,
		.address       = 0x3C,
		.address_width = I2C_ADDRESS_WIDTH_7BIT,
		.flags         = 0,
		.speed_mode    = I2C_STANDARD_SPEED_MODE,
};



wiced_i2c_message_t msg1;	//for storing i2c sensor messages
wiced_i2c_message_t msg2; //for storing i2c button data
wiced_thread_t UpdateDisplayHandle;
wiced_thread_t SecondDisplayHandle;
wiced_thread_t ReadI2CButtonsHandle;
wiced_thread_t ReadI2CSensorsHandle;
wiced_thread_t MQTTPublishHandle;
wiced_semaphore_t MQTTPublishSemaphore;//
wiced_thread_t MQTTSubscribeHandle;
wiced_semaphore_t MQTTSubscribeSemaphore;//
wiced_semaphore_t UpdateDisplaySemaphore;//for writing main display
wiced_semaphore_t SecondDisplaySemaphore;//for adding a second page of display
wiced_semaphore_t ReadI2CButtonsSemaphore;// to monitor the i2c buttons
wiced_semaphore_t ReadI2CSensorsSemaphore;//to monitor the i2c sensors
static wiced_mutex_t i2cMutexHandle; //to make sure i2c is not blocked



#define MQTT_BROKER_ADDRESS                 "a2vkjpd80xdrym.iot.us-east-1.amazonaws.com" // if you create a new thing change this and the certificates
char* WICED_TOPIC       =                   "$aws/things/ww101_02/shadow/update"; //this needs to be unique for each application
char* WICED_TOPIC_SUBSCRIBE = "$aws/things/ww101_02/shadow/update";//this needs to be unique for each application
#define WICED_TOPIC_1                        "TOPIC_1"
#define WICED_TOPIC_2                        "TOPIC_2"
#define WICED_TOPIC_3                        "TOPIC_3"
#define WICED_TOPIC_4                        "TOPIC_4"
#define WICED_TOPIC_5                        "TOPIC_5"
#define WICED_TOPIC_6                        "TOPIC_6"
#define WICED_TOPIC_7                        "TOPIC_7"
#define WICED_TOPIC_8                        "$aws/things/ww101_02/shadow/update"//this needs to be unique for each node
//char* CLIENT_ID          =                 "wiced_publisher_aws_";//this needs to be unique for each node
char* CLIENT_ID          =                 "";//this needs to be unique for each node
#define MQTT_REQUEST_TIMEOUT                (5000)
#define MQTT_REQUEST_TIMEOUT_1                (5000)
#define MQTT_DELAY_IN_MILLISECONDS          (1000)
#define MQTT_MAX_RESOURCE_SIZE              (0x7fffffff)
#define MQTT_PUBLISH_RETRY_COUNT            (3)

//strings used for manipulating received data to be displayed on the LCD
char temp_str1[25];
char temp_str2[25];
char temp_str3[25];
char temp_str4[25];
char temp_str5[25];
char temp_str6[25];
char temp_str7[25];
char temp_str8[25];

//char's to store parsed json data in
static char			  json_data1[8] = "OFF";
static char			  json_data2[8] = "OFF";
static char			  json_data3[8] = "OFF";
static char			  json_data4[16] = "OFF";
static char			  json_data5[24] = "OFF";
static char			  json_data6[8] = "OFF";
static char			  json_data7[8] = "OFF";
static char			  json_data8[8] = "OFF";


//flags used to determine if uart entry is required and if so is it complete for setting network id and name
uint32_t SSIDComplete = 0;
uint32_t PasswordComplete = 0;
uint32_t NameComplete = 0;
uint32_t ClientComplete = 0;
uint32_t initialSSID=0;

uint32_t subscribe_count = 0;//counters to be used to increment the topics
uint32_t publish_count = 0;

/******************************************************
 *               Variable Definitions
 ******************************************************/
static wiced_ip_address_t                   broker_address;
static wiced_mqtt_event_type_t              expected_event;
static wiced_semaphore_t                    publish_msg_semaphore;
static wiced_semaphore_t                    subscribe_msg_semaphore;
static wiced_semaphore_t                    unsubscribe_msg_semaphore;

static wiced_semaphore_t                    wake_semaphore;
static wiced_mqtt_security_t                security;
static uint8_t                              pub_in_progress = 0;
/******************************************************
 *                      Macros
 ******************************************************/




void UpdateDisplayThread(wiced_thread_arg_t arg) // this thread updates the main page of the localised sensor hub
{

	while(1)
	{
		wiced_rtos_get_semaphore(&UpdateDisplaySemaphore, WICED_WAIT_FOREVER); //wait for the semaphore to be set

		WPRINT_APP_INFO(("update display thread\n"));

		/* Setup Display Strings */
		sprintf(temp_str,     "Temp:     %.1f", rx_buffer.temp);
		sprintf(humidity_str, "Humidity: %.1f", rx_buffer.humidity);
		sprintf(light_str,    "Light:    %.1f", rx_buffer.light);
		sprintf(pot_str,      "Pot:      %2.2f", rx_buffer.pot);

		/*Send data to the display */
		wiced_rtos_lock_mutex(&i2cMutexHandle); //lock the i2c to prevent multiple accesses
		u8g_FirstPage(&display);
		do {
			u8g_DrawStr(&display, 0, 5,  temp_str);
			u8g_DrawStr(&display, 0, 20, humidity_str);
			u8g_DrawStr(&display, 0, 35, light_str);
			u8g_DrawStr(&display, 0, 50, pot_str);
		} while (u8g_NextPage(&display));

		wiced_rtos_unlock_mutex(&i2cMutexHandle);//release the i2c interface

	}//end of while 1
}//end of thread


void SecondDisplayThread(wiced_thread_arg_t arg) //this thread is used to display data on a second page of the display
{

	while(1)
	{
		wiced_rtos_get_semaphore(&SecondDisplaySemaphore, WICED_WAIT_FOREVER); //wait for semaphore to be set


		wiced_ip_get_ipv4_address(WICED_STA_INTERFACE, &grsm); //update the ipv4 address if changed
		WPRINT_APP_INFO(("ipv4 address %d.%d.%d.%d \n\r", (grsm.ip.v4>>24 & 0xFF), (grsm.ip.v4>>16 & 0xFF), (grsm.ip.v4>>8 & 0xFF), (grsm.ip.v4 & 0xFF)));

		WPRINT_APP_INFO(("second display thread\n"));
		sprintf(temp_str,     "Temp:     %.1f", rx_buffer.temp);
		sprintf(ip_str,		 "%d.%d.%d.%d",(grsm.ip.v4>>24 & 0xFF), (grsm.ip.v4>>16 & 0xFF), (grsm.ip.v4>>8 & 0xFF), (grsm.ip.v4 & 0xFF));
		sprintf(name_str,	"%s", devicename);

		/* Send data to the display */
		wiced_rtos_lock_mutex(&i2cMutexHandle); //lock i2c interface
		u8g_FirstPage(&display);
		do {
			u8g_DrawStr(&display, 0, 5,  temp_str);
			u8g_DrawStr(&display, 0, 35, name_str);
			u8g_DrawStr(&display, 0, 50, ip_str);

		} while (u8g_NextPage(&display));
		wiced_rtos_unlock_mutex(&i2cMutexHandle);//release the i2c interface

	}//end of while 1
}//end of thread


void RtosTimer(void *arg) //rtos timer - interval configured in main application
{
	wiced_rtos_set_semaphore( &ReadI2CButtonsSemaphore );//set semaphore on every timer event to read buttons

}


void ReadI2CSensorsThread(wiced_thread_arg_t arg) //thread to read sensor data over i2c
{

	while(1)
	{
		wiced_rtos_get_semaphore(&ReadI2CSensorsSemaphore, WICED_WAIT_FOREVER); //wait for semaphore to be set
		/* Tx buffer is used to set the offset */
		uint8_t tx_buffer[] = {TEMPERATURE_REG};
		wiced_i2c_message_t setOffset;
		wiced_i2c_init_tx_message(&setOffset, tx_buffer, sizeof(tx_buffer), RETRIES, DISABLE_DMA);

		wiced_i2c_init_rx_message(&msg1, &rx_buffer, sizeof(rx_buffer), RETRIES, DISABLE_DMA);

		wiced_rtos_lock_mutex(&i2cMutexHandle); //lock i2c
		/* Initialize offset */
		wiced_i2c_transfer(&psoc_i2c, &setOffset, NUM_MESSAGES);

		wiced_i2c_transfer(&psoc_i2c, &msg1, NUM_MESSAGES); /* Get new data from I2C */
		wiced_rtos_unlock_mutex(&i2cMutexHandle); //release i2c

		//depending on which page is set by buttons display one set of information or another by setting appropriate semaphore
		if(page==FIRSTPAGE)
		{
			wiced_rtos_set_semaphore(&UpdateDisplaySemaphore);
		}
		else if(page==SECONDPAGE)
		{
			wiced_rtos_set_semaphore(&SecondDisplaySemaphore);
		}

	}//while1

}//end of thread


//static void publish_callback( void* arg ) //currently unsused function to detect button press as host interrupt rather than over i2c
//{
//}


/*
 * A blocking call to an expected event. used for publish events
 */
static wiced_result_t wait_for_response( wiced_mqtt_event_type_t event, uint32_t timeout )
{
	if ( wiced_rtos_get_semaphore( &publish_msg_semaphore, timeout ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	else
	{
		if ( event != expected_event )
		{
			return WICED_ERROR;
		}
	}
	return WICED_SUCCESS;
}


/*
 * A blocking call to an expected event. used for subscribe events
 */
static wiced_result_t mqtt_wait_for( wiced_mqtt_event_type_t event, uint32_t timeout )
{
	if ( wiced_rtos_get_semaphore( &subscribe_msg_semaphore, timeout ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	else
	{
		if ( event != expected_event )
		{
			return WICED_ERROR;
		}
	}
	return WICED_SUCCESS;
}

static wiced_result_t mqtt_wait_for_unsubscribe( wiced_mqtt_event_type_t event, uint32_t timeout )
{
	if ( wiced_rtos_get_semaphore( &unsubscribe_msg_semaphore, timeout ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	else
	{
		if ( event != expected_event )
		{
			return WICED_ERROR;
		}
	}
	return WICED_SUCCESS;
}

/*
 * Open a connection and wait for MQTT_REQUEST_TIMEOUT period to receive a connection open OK event
 */
static wiced_result_t mqtt_conn_open( wiced_mqtt_object_t mqtt_obj, wiced_ip_address_t *address, wiced_interface_t interface, wiced_mqtt_callback_t callback, wiced_mqtt_security_t *security )
{
	wiced_mqtt_pkt_connect_t conninfo;
	wiced_result_t ret = WICED_SUCCESS;

	memset( &conninfo, 0, sizeof( conninfo ) );
	conninfo.port_number = 0;
	conninfo.mqtt_version = WICED_MQTT_PROTOCOL_VER4;
	conninfo.clean_session = 1;
	conninfo.client_id = (uint8_t*) CLIENT_ID;
	conninfo.keep_alive = 5;
	conninfo.password = NULL;
	conninfo.username = NULL;
	conninfo.peer_cn = (uint8_t*) "*.iot.us-east-1.amazonaws.com";
	ret = wiced_mqtt_connect( mqtt_obj, address, interface, callback, security, &conninfo );
	if ( ret != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	if ( wait_for_response( WICED_MQTT_EVENT_TYPE_CONNECT_REQ_STATUS, MQTT_REQUEST_TIMEOUT ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	return WICED_SUCCESS;
}



/*
 * Publish (send) message to WICED_TOPIC and wait for 5 seconds to receive a PUBCOMP (as it is QoS=2).
 */
static wiced_result_t mqtt_app_publish( wiced_mqtt_object_t mqtt_obj, uint8_t qos, uint8_t *topic, uint8_t *data, uint32_t data_len )
{
	wiced_mqtt_msgid_t pktid;

	pktid = wiced_mqtt_publish( mqtt_obj, topic, data, data_len, qos );

	if ( pktid == 0 )
	{
		return WICED_ERROR;

	}

	if ( wait_for_response( WICED_MQTT_EVENT_TYPE_PUBLISHED, MQTT_REQUEST_TIMEOUT_1 ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	return WICED_SUCCESS;
}

/*
 * Close a connection and wait for 5 seconds to receive a connection close OK event
 */
static wiced_result_t mqtt_conn_close( wiced_mqtt_object_t mqtt_obj )
{
	if ( wiced_mqtt_disconnect( mqtt_obj ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	if ( wait_for_response( WICED_MQTT_EVENT_TYPE_DISCONNECTED, MQTT_REQUEST_TIMEOUT ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	return WICED_SUCCESS;
}



//function to pars shadow json data
static wiced_result_t parse_json_shadow_status(wiced_json_object_t * json_object )
{
	//check to see if the json object contains a string, and if so copy the value after it in to the data array
	if(strncmp(json_object->object_string, "temperature", strlen("temperature")) == 0)
	{
		if(json_object->value_length > 0 && json_object->value_length < sizeof(json_data1)-1)
		{
			memcpy(json_data1, json_object->value, json_object->value_length);
			json_data1[json_object->value_length] = '\0';
		}
	}
	//WPRINT_APP_INFO (( "temperature is  %s\n", json_data1 ));

	if(strncmp(json_object->object_string, "humidity", strlen("humidity")) == 0)
	{
		if(json_object->value_length > 0 && json_object->value_length < sizeof(json_data2)-1)
		{
			memcpy(json_data2, json_object->value, json_object->value_length);
			json_data2[json_object->value_length] = '\0';
		}
	}
	//WPRINT_APP_INFO (( "humidity is  %s\n", json_data2 ));


	if(strncmp(json_object->object_string, "weatherAlert", strlen("weatherAlert")) == 0)
	{
		if(json_object->value_length > 0 && json_object->value_length < sizeof(json_data3)-1)
		{
			memcpy(json_data3, json_object->value, json_object->value_length);
			json_data3[json_object->value_length] = '\0';
		}
	}
	//WPRINT_APP_INFO (( "alert is   %s\n", json_data3 ));

	if(strncmp(json_object->object_string, "DeviceName", strlen("DeviceName")) == 0)
	{
		if(json_object->value_length > 0 && json_object->value_length < sizeof(json_data4)-1)
		{
			memcpy(json_data4, json_object->value, json_object->value_length);
			json_data4[json_object->value_length] = '\0';
		}
	}
	//WPRINT_APP_INFO (( "device name is  %s\n", json_data4 ));

	if(strncmp(json_object->object_string, "IPAddress", strlen("IPAddress")) == 0)
	{
		if(json_object->value_length > 0 && json_object->value_length < sizeof(json_data5)-1)
		{
			memcpy(json_data5, json_object->value, json_object->value_length);
			json_data5[json_object->value_length] = '\0';
		}
	}
	//WPRINT_APP_INFO (( "IPAddress is  %s\n", json_data5 ));

	if(strncmp(json_object->object_string, "pot", strlen("pot")) == 0)
	{
		if(json_object->value_length > 0 && json_object->value_length < sizeof(json_data6)-1)
		{
			memcpy(json_data6, json_object->value, json_object->value_length);
			json_data6[json_object->value_length] = '\0';
		}
	}
	//WPRINT_APP_INFO (( "pot value is  %s\n", json_data6 ));

	if(strncmp(json_object->object_string, "light", strlen("light")) == 0)
	{
		if(json_object->value_length > 0 && json_object->value_length < sizeof(json_data7)-1)
		{
			memcpy(json_data7, json_object->value, json_object->value_length);
			json_data7[json_object->value_length] = '\0';
		}
	}
	//WPRINT_APP_INFO (( "light value is  %s\n", json_data7 ));

	return WICED_SUCCESS;
}



/*
 * Call back function to handle connection events.
 */
static wiced_result_t mqtt_connection_event_cb( wiced_mqtt_object_t mqtt_object_publish, wiced_mqtt_event_info_t *event )
{
	switch ( event->type )
	{
	case WICED_MQTT_EVENT_TYPE_CONNECT_REQ_STATUS:
	case WICED_MQTT_EVENT_TYPE_DISCONNECTED:
	case WICED_MQTT_EVENT_TYPE_PUBLISHED:

	{
		expected_event = event->type;
		wiced_rtos_set_semaphore( &publish_msg_semaphore ); //if it is a publish / connect or disconnect event set semaphore
	}
	break;

	case WICED_MQTT_EVENT_TYPE_SUBCRIBED:
	{
		expected_event = event->type;
		wiced_rtos_set_semaphore( &subscribe_msg_semaphore ); //if there is a subscribe or unsubscribe event set semaphore
	}
	break;

	case WICED_MQTT_EVENT_TYPE_UNSUBSCRIBED:
	{
		expected_event = event->type;
		wiced_rtos_set_semaphore( &unsubscribe_msg_semaphore ); //if there is a subscribe or unsubscribe event set semaphore
	}
	break;

	case WICED_MQTT_EVENT_TYPE_PUBLISH_MSG_RECEIVED:
	{

		wiced_mqtt_topic_msg_t msg = event->data.pub_recvd;
		memcpy( msgS, msg.data, msg.data_len );
		WPRINT_APP_INFO(("msg recieved %s \n\r", msgS));

		ret = wiced_JSON_parser( (const char*)msg.data , msg.data_len ); //pass data received to json parser
		if ( ret == WICED_SUCCESS )
		{

			//format the data to put some of the info on the same line and some on their own line
			sprintf(temp_str1,     "T:%s H:%s", json_data1, json_data2);//temperature & humidity
			sprintf(temp_str3,     "A:%s  %s", json_data3, json_data4);//alert & name
			sprintf(temp_str5,     "%s", json_data5);//ip address
			sprintf(temp_str6,     "P:%s L:%s", json_data6, json_data7);//pot & light

			wiced_rtos_lock_mutex(&i2cMutexHandle); //lock the i2c
			u8g_FirstPage(&display);
			do {
				u8g_DrawStr(&display, 0, 5,  temp_str1);
				u8g_DrawStr(&display, 0, 20, temp_str3);
				u8g_DrawStr(&display, 0, 35,  temp_str5);
				u8g_DrawStr(&display, 0, 50, temp_str6);

			} while (u8g_NextPage(&display));
			wiced_rtos_unlock_mutex(&i2cMutexHandle);//release the i2c
		}

	}
	break;
	default:

		break;
	}
	return WICED_SUCCESS;
}

/*
 * Subscribe to WICED_TOPIC and wait for 5 seconds to receive an ACM.
 */
static wiced_result_t mqtt_app_subscribe( wiced_mqtt_object_t mqtt_obj, char *topic, uint8_t qos )
{
	wiced_mqtt_msgid_t pktid;
	pktid = wiced_mqtt_subscribe( mqtt_obj, topic, qos );
	if ( pktid == 0 )
	{
		return WICED_ERROR;
	}
	if ( mqtt_wait_for( WICED_MQTT_EVENT_TYPE_SUBCRIBED, 5000 ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	return WICED_SUCCESS;
}

static wiced_result_t mqtt_app_unsubscribe( wiced_mqtt_object_t mqtt_obj, char *topic)
{
	wiced_mqtt_msgid_t pktid;
	pktid = wiced_mqtt_unsubscribe( mqtt_obj, topic );
	if ( pktid == 0 )
	{
		return WICED_ERROR;
	}
	if ( mqtt_wait_for_unsubscribe( WICED_MQTT_EVENT_TYPE_UNSUBSCRIBED, 5000 ) != WICED_SUCCESS )
	{
		return WICED_ERROR;
	}
	return WICED_SUCCESS;
}

void MQTTPublishThread(wiced_thread_arg_t arg) //thread to publish sensor data to cloud
{

	while ( 1 )
	{
		wiced_rtos_get_semaphore( &MQTTPublishSemaphore, WICED_NEVER_TIMEOUT );//wait for semaphore to be set

		if ( pub_in_progress == 1 )
		{
			WPRINT_APP_INFO(("[MQTT] Publishing..."));

			sprintf(msg,"{\"state\": { \"reported\":{\"temperature\":%.1f, \"humidity\":%.1f, \"weatherAlert\":%s, \"DeviceName\":\"%s\", \"IPAddress\":\"%s\", \"pot\":%.1f, \"light\":%.1f}}}",rx_buffer.temp, rx_buffer.humidity, alert, name_str, ip_str, rx_buffer.pot, rx_buffer.light );


			retries = 0; // reset retries to 0 before going into the loop so that the next publish after a failure will still work
			do
			{
				ret = mqtt_app_publish( mqtt_object_publish, WICED_MQTT_QOS_DELIVER_AT_MOST_ONCE, (uint8_t*) WICED_TOPIC, (uint8_t*) msg, strlen( msg ) );
				retries++ ;
			} while ( ( ret != WICED_SUCCESS ) && ( retries < MQTT_PUBLISH_RETRY_COUNT ) );
			if ( ret != WICED_SUCCESS )
			{
				WPRINT_APP_INFO((" Failed\n"));
				mqtt_conn_close( mqtt_object_publish );
				MQTT_Open_Function();
				//break;
			}
			else
			{
				WPRINT_APP_INFO((" Success\n"));
			}

			pub_in_progress = 0;//reset flag

		}//end of if pub
	}//end of while1
}//end of thread


void mqtt_subscribe_function(void) //function to subscribe to a mqtt topic
{

	WPRINT_APP_INFO(("[MQTT] Subscribing..."));
	do
	{
		ret = mqtt_app_subscribe( mqtt_object_publish, WICED_TOPIC_SUBSCRIBE, WICED_MQTT_QOS_DELIVER_AT_MOST_ONCE );//subscribe to the defined topic
		retries++ ;
	} while ( ( ret != WICED_SUCCESS ) && ( retries < MQTT_SUBSCRIBE_RETRY_COUNT ) );
	if ( ret != WICED_SUCCESS )
	{
		WPRINT_APP_INFO((" Failed to subscribe\n"));
		mqtt_conn_close( mqtt_object_publish );
		MQTT_Open_Function();
		return;
	}
	WPRINT_APP_INFO(("Success subscribed to topic... %s\n", WICED_TOPIC_SUBSCRIBE));

}

void mqtt_unsubscribe_function(void) //function to unsubscribe from a mqtt topic
{

	WPRINT_APP_INFO(("[MQTT] Unsubscribing..."));
	do
	{
		ret = mqtt_app_unsubscribe( mqtt_object_publish, WICED_TOPIC_SUBSCRIBE);//unsubscribe to the defined topic
		retries1++ ;
	} while ( ( ret != WICED_SUCCESS ) && ( retries1 < MQTT_SUBSCRIBE_RETRY_COUNT ) );
	if ( ret != WICED_SUCCESS )
	{
		WPRINT_APP_INFO((" Failed to unsubscribe\n"));
		mqtt_conn_close( mqtt_object_publish );
		MQTT_Open_Function();
		return;
	}
	WPRINT_APP_INFO(("Success unsubscribed from topic... %s\n", WICED_TOPIC_SUBSCRIBE));

}


void Change_Subscribe_Topic(uint32_t topic)
{
	switch ( topic )
	{
	case 0:
	{
		mqtt_unsubscribe_function();
		WICED_TOPIC_SUBSCRIBE = WICED_TOPIC_8;
		WPRINT_APP_INFO(("topic... %s\n", WICED_TOPIC_SUBSCRIBE));
		mqtt_subscribe_function();
	}
	break;
	case 1:
	{
		mqtt_unsubscribe_function();
		WICED_TOPIC_SUBSCRIBE = WICED_TOPIC_1;
		WPRINT_APP_INFO(("topic... %s\n", WICED_TOPIC_SUBSCRIBE));
		mqtt_subscribe_function();
	}
	break;
	case 2:
	{
		mqtt_unsubscribe_function();
		WICED_TOPIC_SUBSCRIBE = WICED_TOPIC_2;
		WPRINT_APP_INFO(("topic... %s\n", WICED_TOPIC_SUBSCRIBE));
		mqtt_subscribe_function();
	}
	break;
	case 3:
	{
		mqtt_unsubscribe_function();
		WICED_TOPIC_SUBSCRIBE = WICED_TOPIC_3;
		WPRINT_APP_INFO(("topic... %s\n", WICED_TOPIC_SUBSCRIBE));
		mqtt_subscribe_function();
	}
	break;
	case 4:
	{
		mqtt_unsubscribe_function();
		WICED_TOPIC_SUBSCRIBE = WICED_TOPIC_4;
		WPRINT_APP_INFO(("topic... %s\n", WICED_TOPIC_SUBSCRIBE));
		mqtt_subscribe_function();
	}
	break;
	case 5:
	{
		mqtt_unsubscribe_function();
		WICED_TOPIC_SUBSCRIBE = WICED_TOPIC_5;
		WPRINT_APP_INFO(("topic... %s\n", WICED_TOPIC_SUBSCRIBE));
		mqtt_subscribe_function();
	}
	break;
	case 6:
	{
		mqtt_unsubscribe_function();
		WICED_TOPIC_SUBSCRIBE = WICED_TOPIC_6;
		WPRINT_APP_INFO(("topic... %s\n", WICED_TOPIC_SUBSCRIBE));
		mqtt_subscribe_function();
	}
	break;
	case 7:
	{
		mqtt_unsubscribe_function();
		WICED_TOPIC_SUBSCRIBE = WICED_TOPIC_7;
		WPRINT_APP_INFO(("topic... %s\n", WICED_TOPIC_SUBSCRIBE));
		mqtt_subscribe_function();
	}
	break;
	default:

		break;
	}


}


void Change_Publish_Topic(uint32_t topic)
{
	switch ( topic )
	{
	case 0:
	{
		WICED_TOPIC = WICED_TOPIC_8;
		WPRINT_APP_INFO(("publish topic... %s\n", WICED_TOPIC));
	}
	break;
	case 1:
	{
		WICED_TOPIC = WICED_TOPIC_1;
		WPRINT_APP_INFO(("publish topic... %s\n", WICED_TOPIC));

	}
	break;
	case 2:
	{
		WICED_TOPIC = WICED_TOPIC_2;
		WPRINT_APP_INFO(("publish topic... %s\n", WICED_TOPIC));

	}
	break;
	case 3:
	{
		WICED_TOPIC = WICED_TOPIC_3;
		WPRINT_APP_INFO(("publish topic... %s\n", WICED_TOPIC));

	}
	break;
	case 4:
	{
		WICED_TOPIC = WICED_TOPIC_4;
		WPRINT_APP_INFO(("publish topic... %s\n", WICED_TOPIC));

	}
	break;
	case 5:
	{
		WICED_TOPIC = WICED_TOPIC_5;
		WPRINT_APP_INFO(("publish topic... %s\n", WICED_TOPIC));

	}
	break;
	case 6:
	{
		WICED_TOPIC = WICED_TOPIC_6;
		WPRINT_APP_INFO(("publish topic... %s\n", WICED_TOPIC));

	}
	break;
	case 7:
	{
		WICED_TOPIC = WICED_TOPIC_7;
		WPRINT_APP_INFO(("publish topic... %s\n", WICED_TOPIC));

	}
	break;


	}
}

void ReadI2CButtonsThread(wiced_thread_arg_t arg) //thread to read the i2c buttons to see if anything has been pressed
{

	while(1)
	{
		wiced_rtos_get_semaphore(&ReadI2CButtonsSemaphore, WICED_WAIT_FOREVER); //get the semaphore
		/* Tx buffer is used to set the offset */
		uint8_t tx_buffer[] = {BUTTON_REG};
		wiced_i2c_message_t setOffset;
		wiced_i2c_init_tx_message(&setOffset, tx_buffer, sizeof(tx_buffer), RETRIES, DISABLE_DMA);

		wiced_i2c_init_rx_message(&msg2, &rx_buffer1, sizeof(rx_buffer1), RETRIES, DISABLE_DMA);

		/* Initialize offset */
		wiced_rtos_lock_mutex(&i2cMutexHandle);
		wiced_i2c_transfer(&psoc_i2c, &setOffset, NUM_MESSAGES);

		wiced_i2c_transfer(&psoc_i2c, &msg2, NUM_MESSAGES); /* Get new data from I2C */
		wiced_rtos_unlock_mutex(&i2cMutexHandle);

		/* place holders have been added for using all the buttons on the shield*/
		if(rx_buffer1.ButtonStatus >>5 & 0x1)//mb1 - if mech button1 pressed change the subscribe topic
		{
			subscribe_count++;
			if(subscribe_count==8)
			{
				subscribe_count=0;
			}
			Change_Subscribe_Topic(subscribe_count);
		}

		if(rx_buffer1.ButtonStatus >>4 & 0x1)//mb0 - if mech button 0 pressed change the publish topic
		{
			publish_count++;
			if(publish_count==8)
			{
				publish_count=0;
			}
			Change_Publish_Topic(publish_count);
		}
		//		if(rx_buffer1.ButtonStatus >>3 & 0x1)//b3 -if cap b3
		//		{

		//		}
		//		if(rx_buffer1.ButtonStatus >>2 & 0x1)//b2 - if cap b2
		//		{

		//		}
		if(rx_buffer1.ButtonStatus >>1 & 0x1)//B1 - if cap button 1 pressed
		{
			page = SECONDPAGE;//change what to display on the screen
			if(pub_in_progress == 0)
			{
				pub_in_progress = 1;
				wiced_rtos_set_semaphore( &ReadI2CSensorsSemaphore ); //instruct device to read i2c sensor data
				wiced_rtos_set_semaphore( &MQTTPublishSemaphore );//then create package to write publish

			}
		}
		if(rx_buffer1.ButtonStatus  & 0x1) //B0 - if cap button 0 pressed
		{

			//if button pressed send a report
			page = FIRSTPAGE;//change what to display on the screen
			if(pub_in_progress == 0)
			{
				pub_in_progress = 1;
				wiced_rtos_set_semaphore( &ReadI2CSensorsSemaphore ); //instruct device to read i2c sensor data
				wiced_rtos_set_semaphore( &MQTTPublishSemaphore );//then create package to write publish

			}
		}//end of if button

	}//end of while1
}//end of thread


void print_network_info( )
{
	platform_dct_wifi_config_t*  wifi_config;

	// Get a copy of the WIFT config from the DCT into RAM
	wiced_dct_read_lock((void**) &wifi_config, WICED_FALSE, DCT_WIFI_CONFIG_SECTION, 0, sizeof(platform_dct_wifi_config_t));

	// Print info
	WPRINT_APP_INFO(("SSID = %s\n\r",wifi_config->stored_ap_list[0].details.SSID.value));
	WPRINT_APP_INFO(("Security = %d\n\r",wifi_config->stored_ap_list[0].details.security));
	WPRINT_APP_INFO(("Passphrase = %s\n\r",wifi_config->stored_ap_list[0].security_key));

	// Free RAM buffer
	wiced_dct_read_unlock(wifi_config, WICED_FALSE);
}

void Set_Network_ID(void)
{

	static char ssid[25] = ""; //variables to store inputted data
	static char password[25] = "";
	static char name[25] = "";
	static char client[25] = "";

	char c;
	uint32_t i=0;
	uint32_t expected_data_size = 1;
	platform_dct_wifi_config_t*  wifi_config;

#define SSID_STR          "\r\nEnter SSID. Press Esc to restart or Carriage Return when complete\r\n> "
#define PASS_STR          "\r\nEnter Password. Press Esc to restart or Carriage Return when complete\r\n> "
#define NAME_STR          "\r\nEnter Device Name. e.g. ww101_x Press Esc to restart or Carriage Return when complete\r\n> "
#define CLIENT_STR          "\r\nEnter Client number. Type Client_xx where xx is a different number per node Press Esc to restart or Carriage Return when complete\r\n> "

#define SECURITY   WICED_SECURITY_WPA2_MIXED_PSK
#define cr	"\r\n"
	wiced_result_t res;

	wiced_uart_transmit_bytes( STDIO_UART, SSID_STR, sizeof( SSID_STR ) - 1 ); //send ssid string
	while(SSIDComplete!=1)
	{

		/* Wait for user input. If received, echo it back to the terminal */
		if( wiced_uart_receive_bytes( STDIO_UART, &c, &expected_data_size, WICED_NEVER_TIMEOUT ) == WICED_SUCCESS )
		{

			if(c==0xD) //if CR pressed
			{
				wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) ); //send return
				wiced_uart_transmit_bytes( STDIO_UART, ssid, strlen(ssid) ); //print the enterred ssid
				wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
				SSIDComplete=1;

				i=0;
			}
			else if(c==0x1B) //if escape pressed reset string pointer
			{

				i=0;
			}
			else //if valid character add it to string and echo to display
			{
				ssid[i] = c;
				wiced_uart_transmit_bytes( STDIO_UART, &c, 1 );
				expected_data_size = 1;
				i++;
			}

		}

	}

	wiced_uart_transmit_bytes( STDIO_UART, PASS_STR, sizeof( PASS_STR ) - 1 ); //send password string
	while(PasswordComplete!=1)
	{

		/* Wait for user input. If received, echo it back to the terminal */
		if( wiced_uart_receive_bytes( STDIO_UART, &c, &expected_data_size, WICED_NEVER_TIMEOUT ) == WICED_SUCCESS )
		{

			if(c==0xD)
			{
				wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
				wiced_uart_transmit_bytes( STDIO_UART, password, strlen(password) );
				wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
				PasswordComplete=1;

				i=0;
			}
			else if(c==0x1B)
			{
				i=0;
			}
			else
			{
				password[i] = c;
				wiced_uart_transmit_bytes( STDIO_UART, &c, 1 );
				expected_data_size = 1;
				i++;
			}

		}

	}


	wiced_uart_transmit_bytes( STDIO_UART, NAME_STR, sizeof( NAME_STR ) - 1 ); //send name string
	while(NameComplete!=1)
	{

		/* Wait for user input. If received, echo it back to the terminal */
		if( wiced_uart_receive_bytes( STDIO_UART, &c, &expected_data_size, WICED_NEVER_TIMEOUT ) == WICED_SUCCESS )
		{

			if(c==0xD)
			{
				wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
				wiced_uart_transmit_bytes( STDIO_UART, name, strlen(name) );
				wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
				NameComplete=1;

				i=0;
			}
			else if(c==0x1B)
			{
				i=0;
			}
			else
			{
				name[i] = c;
				wiced_uart_transmit_bytes( STDIO_UART, &c, 1 );
				expected_data_size = 1;
				i++;
			}

		}

	}



	devicename = name; //set the device name and client to the same inputted string for simplicity
	CLIENT_ID = name;

	WPRINT_APP_INFO(("devicename = %s\n\r",devicename));
	WPRINT_APP_INFO(("client id = %s\n\r",CLIENT_ID));


	if(initialSSID==0) //if not already connected at start up, bring the network down and update the DCT with enterred data
	{
		wiced_network_down(WICED_STA_INTERFACE); //take network down

		wiced_dct_read_lock((void**) &wifi_config, WICED_TRUE, DCT_WIFI_CONFIG_SECTION, 0, sizeof(platform_dct_wifi_config_t));
		strncpy((char *)wifi_config->stored_ap_list[0].details.SSID.value , ssid, strlen(ssid));
		strncpy((char *)wifi_config->stored_ap_list[0].security_key , password, strlen(password));
		wifi_config->stored_ap_list[0].details.security = WICED_SECURITY_WPA2_MIXED_PSK;
		wifi_config->stored_ap_list[0].security_key_length = strlen(password);
		wifi_config->stored_ap_list[0].details.SSID.length = strlen(ssid);



		// Write updated parameters to the DCT
		res = wiced_dct_write((const void *) wifi_config, DCT_WIFI_CONFIG_SECTION, 0, sizeof(platform_dct_wifi_config_t));
		if(res == WICED_SUCCESS)
		{
			WPRINT_APP_INFO(("DCT write SUCCEEDED\n\r"));
		}
		else
		{
			WPRINT_APP_INFO(("DCT write FAILED\n\r"));
		}

		wiced_dct_read_unlock(wifi_config, WICED_TRUE);
		print_network_info();


		/* Bring up the network interface */
		ret = wiced_network_up( WICED_STA_INTERFACE, WICED_USE_EXTERNAL_DHCP_SERVER, NULL );
		if ( ret != WICED_SUCCESS )
		{
			WPRINT_APP_INFO( ( "\nNot able to join the requested AP\n\n" ) );
			return;
		}

	}//end if initialssid
}

void MQTT_Open_Function(void)
{
	WPRINT_APP_INFO(("[MQTT] Opening connection publish ..."));
	do
	{
		ret = mqtt_conn_open( mqtt_object_publish, &broker_address, WICED_STA_INTERFACE, mqtt_connection_event_cb, &security );
		connection_retries++ ;
	} while ( ( ret != WICED_SUCCESS ) && ( connection_retries < WICED_MQTT_CONNECTION_NUMBER_OF_RETRIES ) );

	if ( ret != WICED_SUCCESS )
	{
		WPRINT_APP_INFO(("Failed\n"));

	}
	WPRINT_APP_INFO(("Success publish connection\n"));


}

/******************************************************
 *               Function Definitions
 ******************************************************/
void application_start( void )
{

	wiced_timer_t timerHandle;
	platform_dct_wifi_config_t*  wifi_config;
	wiced_init( );

	wiced_result_t res;
	res = wiced_network_up(WICED_STA_INTERFACE, WICED_USE_EXTERNAL_DHCP_SERVER, NULL);
	if(res==0) //if we connect to the network pre stored in the dct, set the flags to skip entry request over uart
	{
		SSIDComplete=1;
		PasswordComplete = 1;
		initialSSID = 1;
	}
	Set_Network_ID(); //set ssid if required, password if required, and device name

	//security setup

	/* Get AWS root certificate, client certificate and private key respectively */
	//the privkey and client key may need to be unique for each device. if changed they need to be changed in the mk file as well
	resource_get_readonly_buffer( &resources_apps_DIR_aws_iot_DIR_ww02_DIR_rootca_cer, 0, MQTT_MAX_RESOURCE_SIZE, &size_out, (const void **) &security.ca_cert );
	security.ca_cert_len = size_out;

	resource_get_readonly_buffer( &resources_apps_DIR_aws_iot_DIR_ww02_DIR_client_cer, 0, MQTT_MAX_RESOURCE_SIZE, &size_out, (const void **) &security.cert );
	if(size_out < 64)
	{
		WPRINT_APP_INFO( ( "\nNot a valid Certificate! Please replace the dummy certificate file 'resources/app/aws_iot/client.cer' with the one got from AWS\n\n" ) );
		return;
	}
	security.cert_len = size_out;

	resource_get_readonly_buffer( &resources_apps_DIR_aws_iot_DIR_ww02_DIR_privkey_cer, 0, MQTT_MAX_RESOURCE_SIZE, &size_out, (const void **) &security.key );
	if(size_out < 64)
	{
		WPRINT_APP_INFO( ( "\nNot a valid Private Key! Please replace the dummy private key file 'resources/app/aws_iot/privkey.cer' with the one got from AWS\n\n" ) );
		return;
	}
	security.key_len = size_out;

	//end of security setup


	//mqtt setup
	/* Allocate memory for MQTT object*/
	mqtt_object_publish = (wiced_mqtt_object_t) malloc( WICED_MQTT_OBJECT_MEMORY_SIZE_REQUIREMENT );
	if ( mqtt_object_publish == NULL )
	{
		WPRINT_APP_ERROR("Dont have memory to allocate for mqtt object publish...\n");
		return;
	}



	WPRINT_APP_INFO( ( "Resolving IP address of MQTT broker...\n" ) );
	ret = wiced_hostname_lookup( MQTT_BROKER_ADDRESS, &broker_address, 10000 );
	WPRINT_APP_INFO(("Resolved Broker IP: %u.%u.%u.%u\n\n", (uint8_t)(GET_IPV4_ADDRESS(broker_address) >> 24),
			(uint8_t)(GET_IPV4_ADDRESS(broker_address) >> 16),
			(uint8_t)(GET_IPV4_ADDRESS(broker_address) >> 8),
			(uint8_t)(GET_IPV4_ADDRESS(broker_address) >> 0)));
	if ( ret == WICED_ERROR || broker_address.ip.v4 == 0 )
	{
		WPRINT_APP_INFO(("Error in resolving DNS\n"));
		return;
	}


	////thread,semaphore,mutex and timer setup

	/* Initialize the Mutex */
	wiced_rtos_init_mutex(&i2cMutexHandle); //initialise a lock to prevent i2c collision

	/* Initialize and start a timer */
	wiced_rtos_init_timer(&timerHandle, TIMER_TIME, RtosTimer, NULL); //will run ~every 100ms
	wiced_rtos_start_timer(&timerHandle);


	wiced_rtos_init_semaphore(&UpdateDisplaySemaphore);
	wiced_rtos_init_semaphore(&SecondDisplaySemaphore);
	wiced_rtos_init_semaphore(&ReadI2CButtonsSemaphore);
	wiced_rtos_init_semaphore(&ReadI2CSensorsSemaphore);
	wiced_rtos_init_semaphore(&MQTTPublishSemaphore);
	wiced_rtos_init_semaphore(&publish_msg_semaphore);
	wiced_rtos_init_semaphore(&MQTTSubscribeSemaphore);
	wiced_rtos_init_semaphore(&subscribe_msg_semaphore);
	wiced_rtos_init_semaphore(&unsubscribe_msg_semaphore);

	wiced_rtos_create_thread(&MQTTPublishHandle, 10, "MQTTPublishhread", &MQTTPublishThread, 40048, NULL);
	wiced_rtos_create_thread(&UpdateDisplayHandle, 10, "UpdateDisplayThread", &UpdateDisplayThread, 10024, NULL);
	wiced_rtos_create_thread(&SecondDisplayHandle, 10, "SecondeDisplayThread", &SecondDisplayThread, 10024, NULL);
	wiced_rtos_create_thread(&ReadI2CButtonsHandle, 10, "ReadI2CButtonsThread", &ReadI2CButtonsThread, 10024, NULL);
	wiced_rtos_create_thread(&ReadI2CSensorsHandle, 10, "ReadI2CSensorsThread", &ReadI2CSensorsThread, 10024, NULL);


	wiced_mqtt_init( mqtt_object_publish );

	//configure the i2c interface for the display and the sensors

	u8g_init_wiced_i2c_device(&display_i2c);//configure the display setting

	u8g_InitComFn(&display, &u8g_dev_ssd1306_128x64_i2c, u8g_com_hw_i2c_fn);
	u8g_SetFont(&display, u8g_font_unifont);
	u8g_SetFontPosTop(&display);

	wiced_i2c_init(&psoc_i2c);


	wiced_JSON_parser_register_callback(parse_json_shadow_status);

	wiced_ip_get_ipv4_address(WICED_STA_INTERFACE, &grsm);//store the local ipv4 address in to an array for use by the display
	sprintf(ip_str,		 "ip:%d.%d.%d.%d",(grsm.ip.v4>>24 & 0xFF), (grsm.ip.v4>>16 & 0xFF), (grsm.ip.v4>>8 & 0xFF), (grsm.ip.v4 & 0xFF));//store in to local string

	do
	{
		MQTT_Open_Function(); //call function to open and tell device which topic to publish to

		mqtt_subscribe_function(); //call function to subscribe to a defined topic


		/* configure push button to publish a message */
		// wiced_gpio_input_irq_enable( WICED_SH_MB1, IRQ_TRIGGER_RISING_EDGE, publish_callback, NULL );

		while ( 1 )
		{

			wiced_rtos_delay_milliseconds( 10 ); //delay here to allow other threads to run
		}

		//we should never get here

		pub_in_progress = 0; // Reset flag if we got a failure so that another button push is needed after a failure

		WPRINT_APP_INFO(("[MQTT] Closing connection..."));
		mqtt_conn_close( mqtt_object_publish );


		wiced_rtos_delay_milliseconds( MQTT_DELAY_IN_MILLISECONDS * 2 );
	} while ( 1 );

	wiced_rtos_deinit_semaphore( &publish_msg_semaphore );
	WPRINT_APP_INFO(("[MQTT] Deinit connection...\n"));
	ret = wiced_mqtt_deinit( mqtt_object_publish );
	wiced_rtos_deinit_semaphore( &wake_semaphore );
	free( mqtt_object_publish );
	mqtt_object_publish = NULL;

	return;
}
